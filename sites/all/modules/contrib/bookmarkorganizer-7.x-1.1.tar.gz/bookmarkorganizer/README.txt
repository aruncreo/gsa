Bookmark Organizer extends Flag module by providing functionality to 
- arrange bookmarks by drag and drop them
- create folders and place bookmarks into them
- rename bookmarks and folders
- show previews about bookmarks and contents of a folder (optional, Views module required)
- publish bookmarks (stored in a folder) to others

