<?php
// $Id$

/**
 * @file
 * The Bookmark Organizer Slideshow page template.
 */
 
/**
 * @see modules/system/page.tpl.php
 */

render($page['content']);
